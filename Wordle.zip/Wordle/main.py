from flask import Flask, render_template, url_for, request, redirect, session, g
import sqlite3, os, hashlib, re
from wordle import *

app = Flask(__name__)
app.secret_key = os.urandom(115)

def encrypt_string(hash_string):
    sha_signature = \
        hashlib.sha256(hash_string.encode()).hexdigest()
    return sha_signature

def get_password(username):
    con = sqlite3.connect('database.db')
    cursor = con.cursor()
    data = [Passwords[0] for Passwords in cursor.execute('SELECT Passwords FROM Infos WHERE Usernames = ?', (username,))]
    con.close()
    if data != []:
        return data[0]
    else: 
        return None

def add_data(myNewUsername, myNewPassword):
    try:
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute('INSERT INTO Infos(Usernames, Passwords, Score) VALUES(?, ?, 0)', (myNewUsername,myNewPassword, ))
        con.commit()
        con.close()
    except:
        print("An error has occured")

def get_score(username):
    con = sqlite3.connect('database.db')
    cursor = con.cursor()
    data = [Passwords[0] for Passwords in cursor.execute('SELECT Score FROM Infos WHERE Usernames = ?', (username,))]
    con.close()
    if data != []:
        return data[0]
    else: 
        return None

def update_score(username, score):
    try:
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        score = get_score(username)+score
        cursor.execute('UPDATE Infos SET Score = ? WHERE Usernames = ?', (score,username, ))
        con.commit()
        con.close()
    except:
        print("An error has occured")

def score_num_tries(num_tries):
    if num_tries == 6:
        return 100
    elif num_tries == 5:
        return 200
    elif num_tries == 4:
        return 500
    elif num_tries == 3:
        return 1000
    elif num_tries == 2:
        return 2000
    elif num_tries == 1:
        return 5000
    else: 
        return 0

def get_leaders():
    con = sqlite3.connect('database.db')
    cursor = con.cursor()
    data_username = [Passwords[1] for Passwords in cursor.execute('SELECT * FROM Infos LIMIT 5;')]
    data_score = [Passwords[3] for Passwords in cursor.execute('SELECT * FROM Infos LIMIT 5;')]
    data_score, data_username = zip(*sorted(zip(data_score, data_username)))
    con.close()
    if data_username != []:
        return [data_username, data_score]
    else: 
        return None

    

@app.route("/changelevel", methods=["POST"])
def change_level():
    session['level'] = random.randint(0,160)
    session['colors_in_words'] = []
    session['message'] = []
    session['gameFinished'] = False
    return redirect(url_for("main"))

@app.route("/")
def main():
    if g.user:
        if session['gameFinished']:
            button_state = 'type="submit"'
        else:
            button_state = 'hidden'
        color_in_words = session['colors_in_words']
        score = get_score(g.user)
        leaders = get_leaders()
        return render_template("index.html", user=session['user'], color_in_words=color_in_words, message=session['message'], score=score, button_state=button_state, leaders=leaders)
    return redirect(url_for('login'))

@app.route("/create", methods=["POST","GET"])
def create():
    text = ""
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        passwordVal = request.form['passwordValidation']
        if passwordVal == password:
            add_data(username,encrypt_string(password))
            return redirect(url_for('login'))
        else:
            text = "Les mots de passe ne correspondent pas"

    return render_template("create_account.html", text=text)

@app.route("/login", methods=["POST","GET"])
def login():
    text = ''
    if request.method == "POST":
        session.pop('user', None)
        username = request.form['username']
        password = request.form['password']
        if encrypt_string(password) == get_password(username):
            session['user'] = username
            session['colors_in_words'] = []
            session['message'] = []
            session['level'] = random.randint(0,160)
            session['gameFinished'] = False
            return redirect(url_for('main'))
        
        text="Mauvais nom d'utilisateur ou mot de passe"

    return render_template("login.html", text=text)

@app.route('/logout',methods=['POST'])
def logout():
    session.pop('user', None)
    session.pop('colors_in_words', None)
    session.pop('message', None)
    session.pop('level', None)
    session.pop('gameFinished', None)
    return redirect(url_for('login'))

@app.route('/send', methods=['POST', 'GET'])
def send():
    if request.method == "POST":
        if session['gameFinished'] == False:
            word = request.form['word']

            if len(word) == 5:
                x = re.search("[A-Za-z]{5}", word)
                if x:
                    word = word.lower()
                    if word in mots_valide_func():
                        couleurs = wordle(word, lm[session['level']])
                        color_and_word = []
                        for i in range(5):
                            color_and_word.append([word[i], couleurs[i]])
                        session['colors_in_words'] += color_and_word
                        session['message'] = []
                        if couleurs == ['green', 'green','green','green','green',]:
                            session['message'] = ['Vous avez trouvé le mot!', 'green']
                            score = score_num_tries(len(session['colors_in_words'])/5)
                            update_score(g.user, score)
                            session['gameFinished'] = True
                            return redirect(url_for('main'))
                        elif len(session['colors_in_words']) == 30:
                            session['message'] = ['Vous avez perdu!', 'red']
                            session['gameFinished'] = True
                            return redirect(url_for('main'))
                    else:
                        session['message'] = ['Mot invalide', 'red']
                
                
        return redirect(url_for('main'))
    return redirect(url_for('main'))


@app.before_request
def before_request():
    g.user = None

    if 'user' in session:
        g.user = session['user']

if __name__ == "__main__":
    app.run(host="172.29.1.147", port=8080)