import string
from mot import mots  
import random  
import time
from motvalide import mots_valide

lm = []

alph = "abcdefghijklmnopqrstuvwxyz"

for mot in mots:
    mot = mot.lower()
    d = False
    
    if len(mot) == 5:
        
        
        for lettre in mot:
            if lettre not in alph:
                d = True
        if d == False:
            lm.append(mot)

def mots_valide_func():
    lm_valide=[]

    for nouns in mots_valide:
        nouns = nouns.lower()
        d = False
        
        if len(nouns) == 5:
            
            
            for lettre in nouns:
                if lettre not in alph:
                    d = True
            if d == False:
                lm_valide.append(nouns)
    return lm_valide

def mtol(mot):
    mot_liste = []
    for i in mot:
        mot_liste.append(i)
        
    return mot_liste



def wordle(mot_test, mot_bon):
    
    
    mot_test = mtol(mot_test)
    mot_bon = mtol(mot_bon)
    
    list_codec = ["","","","",""]
    
    
    for i in range (5):
        
        if mot_test[i] == mot_bon[i]:
            list_codec[i] = "green"
            
            mot_test[i] = '0'
            mot_bon[i] = '0'
                      

    for i in range(5):

        if mot_test[i] not in mot_bon[i]:
            list_codec[i] = "grey"
            
    for i in range(5):       
        
        if mot_test[i] in mot_bon and mot_test[i] != mot_bon[i]:
            list_codec[i] = "orange"
            
            a = mot_bon.index(mot_test[i])
            mot_bon[a]='1'
            
        
    return list_codec


print(wordle("pomme", "poire"))


